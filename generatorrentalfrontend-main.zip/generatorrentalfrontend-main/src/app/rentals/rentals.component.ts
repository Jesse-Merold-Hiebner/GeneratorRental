import { Component } from '@angular/core';
import { AddressService } from '../service/address';
import { Address } from '../interface/address';

@Component({
  selector: 'app-rentals',
  templateUrl: './rentals.component.html',
  styleUrls: ['./rentals.component.css']
})
export class RentalsComponent {

  //public address: Address[];

  //constructor(private addressSaer)

}
