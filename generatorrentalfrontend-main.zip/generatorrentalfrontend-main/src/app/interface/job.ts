export interface Job{
    jobId: number;
    jobTitle: string;
    wage: number;
}