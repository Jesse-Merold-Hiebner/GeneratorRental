import { sales } from "./sales";


export interface calloutServices{

    serviceId: number;
    dateOfCallout: Date;
    salesId: sales
}