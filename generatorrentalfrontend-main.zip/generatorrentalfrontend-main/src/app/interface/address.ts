export interface Address{
    addresId: number;
    streetName: string;
    houseNumber: string;
    postalCode: number;
    townName: string;


    

}