export interface Insurance{
    insuranceId: number;
    type: string;
    cost: number;
    
}