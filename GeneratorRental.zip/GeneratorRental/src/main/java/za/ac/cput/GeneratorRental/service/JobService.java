package za.ac.cput.GeneratorRental.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import za.ac.cput.GeneratorRental.domain.Insurance;
import za.ac.cput.GeneratorRental.domain.Job;
import za.ac.cput.GeneratorRental.repository.JobRepository;

import java.util.List;

@Service
public class JobService {
    @Autowired
    private JobRepository REPOSITORY;

    public Job create(Job job){
        return REPOSITORY.save(job);
    }

    public Job read(long id){
        try {
            return REPOSITORY.findById(id).get();
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid Job Id");
        }
    }

    public Job update(Job job){
        try{
            Job updated = new Job.Builder().copy(this.read(job.getJob_id()))
                    .setJob_title(job.getJob_title())
                    .setWage(job.getWage())
                    .setEmployee(job.getEmployee())
                    .build();
            return REPOSITORY.save(updated);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid Job Id");
        }
    }

    public boolean delete(long id){
        try {
            REPOSITORY.deleteById(id);
            return true;
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid Job Id");
        }
    }

    public List<Job> getAll(){
        return REPOSITORY.findAll();
    }
}
