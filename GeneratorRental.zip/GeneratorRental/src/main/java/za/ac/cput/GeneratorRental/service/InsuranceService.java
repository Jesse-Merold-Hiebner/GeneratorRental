package za.ac.cput.GeneratorRental.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import za.ac.cput.GeneratorRental.domain.Insurance;
import za.ac.cput.GeneratorRental.repository.InsuranceRepository;

import java.util.List;

@Service
public class InsuranceService {
    @Autowired
    private InsuranceRepository REPOSITORY;

    public Insurance create(Insurance insurance){
        return REPOSITORY.save(insurance);
    }

    public Insurance read(long id){
        try {
            return REPOSITORY.findById(id).get();
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid insurance Id");
        }
    }

    public Insurance update(Insurance insurance){
        try{
            Insurance updated = new Insurance.Builder().copy(this.read(insurance.getInsurance_id()))
                    .type(insurance.getType())
                    .cost_per_day(insurance.getCost_per_day())
                    .sales(insurance.getSales())
                    .build();
            return REPOSITORY.save(updated);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid insurance Id");
        }
    }

    public boolean delete(long id){
        try {
            REPOSITORY.deleteById(id);
            return true;
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid insurance Id");
        }
    }

    public List<Insurance> getAll(){
        return REPOSITORY.findAll();
    }
}
