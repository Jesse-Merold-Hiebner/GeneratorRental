package za.ac.cput.GeneratorRental.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import za.ac.cput.GeneratorRental.domain.Product;
import za.ac.cput.GeneratorRental.repository.ProductRepository;

import java.util.List;

@Service
public class ProductService {
    @Autowired
    private ProductRepository REPOSITORY;

    public Product create(Product product){
        return REPOSITORY.save(product);
    }

    public Product read(long id){
        try {
            return REPOSITORY.findById(id).get();
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid product Id");
        }
    }

    public Product update(Product product){
        try{
            Product updated = new Product.Builder().copy(this.read(product.getProduct_id()))
                    .setSerial_number(product.getSerial_number())
                    .setCost_per_day(product.getCost_per_day())
                    .available(product.getAvailable())
                    .setSupplier(product.getSupplier())
                    .sales(product.getSales())
                    .build();
            return REPOSITORY.save(updated);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid product Id");
        }
    }

    public boolean delete(long id){
        try {
            REPOSITORY.deleteById(id);
            return true;
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid product Id");
        }
    }

    public List<Product> getAll(){
        return  REPOSITORY.findAll();
    }
}
