package za.ac.cput.GeneratorRental.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import za.ac.cput.GeneratorRental.domain.Employee;
import za.ac.cput.GeneratorRental.repository.EmployeeRepository;

import java.util.List;

@Service
public class EmployeeService {
    @Autowired
    private EmployeeRepository REPOSITORY;

    public Employee create(Employee employee){
        return REPOSITORY.save(employee);
    }

    public Employee read(long id){
        try {
            return REPOSITORY.findById(id).get();
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid employee Id");
        }
    }

    public Employee update(Employee employee){
        try{
            Employee updated = new Employee.Builder().copy(this.read(employee.getEmployee_id()))
                    .firstName(employee.getFirst_name())
                    .lastName(employee.getLast_name())
                    .contactNo(employee.getContact_no())
                    .user(employee.getUser())
                    .address(employee.getAddress())
                    .job(employee.getJob())
                    .sales(employee.getSales())
                    .build();
            return this.REPOSITORY.save(updated);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid employee Id");
        }
    }

    public boolean delete(long id){
        try {
            REPOSITORY.deleteById(id);
            return true;
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid employee Id");
        }
    }

    public List<Employee> getAll(){
        return REPOSITORY.findAll();
    }
}
