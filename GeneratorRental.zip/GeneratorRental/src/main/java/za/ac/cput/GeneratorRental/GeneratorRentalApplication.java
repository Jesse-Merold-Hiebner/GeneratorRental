package za.ac.cput.GeneratorRental;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GeneratorRentalApplication {

	public static void main(String[] args) {
		SpringApplication.run(GeneratorRentalApplication.class, args);
	}

}
