package za.ac.cput.GeneratorRental.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import za.ac.cput.GeneratorRental.domain.Product;
import za.ac.cput.GeneratorRental.domain.Sales;
import za.ac.cput.GeneratorRental.repository.SalesRepository;

import java.util.List;

@Service
public class SalesService {
    @Autowired
    private SalesRepository REPOSITORY;

    public Sales create(Sales sales){
        return REPOSITORY.save(sales);
    }

    public Sales read(long id){
        try {
            return REPOSITORY.findById(id).get();
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid sales Id");
        }
    }

    public Sales update(Sales sales){
        try {
            Sales updated = new Sales.Builder().copy(this.read(sales.getSales_id()))
                    .totalCost(sales.getTotal_cost())
                    .date(sales.getDate())
                    .customer(sales.getCustomer())
                    .employee(sales.getEmployee())
                    .product(sales.getProduct())
                    .calloutService(sales.getCalloutService())
                    .insurance(sales.getInsurance())
                    .build();
            return REPOSITORY.save(updated);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid Sales Id");
        }
    }

    public boolean delete(long id){
        try {
            REPOSITORY.deleteById(id);
            return true;
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid Sales Id");
        }
    }

    public List<Sales> getAll(){
        return REPOSITORY.findAll();
    }
}
