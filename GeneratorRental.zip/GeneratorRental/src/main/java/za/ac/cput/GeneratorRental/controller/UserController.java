package za.ac.cput.GeneratorRental.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import za.ac.cput.GeneratorRental.domain.User;
import za.ac.cput.GeneratorRental.service.UserService;

import java.util.List;

@RestController
@RequestMapping("generatorrental/user/")
@Slf4j
public class UserController {
    @Autowired
    private UserService SERVICE;

    @PostMapping("create")
    public ResponseEntity<User> create(@RequestBody User user){
        return ResponseEntity.ok(SERVICE.create(user));
    }

    @GetMapping("read/{id}")
    public ResponseEntity<User> read(@PathVariable String id){
        return ResponseEntity.ok(SERVICE.read(id));
    }

    @PutMapping("update")
    public ResponseEntity<User> update(@RequestBody User user){
        return ResponseEntity.ok(SERVICE.update(user));
    }

    @DeleteMapping("delete/{id}")
    public ResponseEntity<Boolean> delete(@PathVariable String id){
        return ResponseEntity.ok(SERVICE.delete(id));
    }

    @GetMapping("getAll")
    public ResponseEntity<List<User>> getAll(){
        return ResponseEntity.ok(SERVICE.getAll());
    }
}
