package za.ac.cput.GeneratorRental.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import za.ac.cput.GeneratorRental.domain.User;
import za.ac.cput.GeneratorRental.repository.UserRepository;

import java.util.List;

@Service
public class UserService {
    @Autowired
    private UserRepository REPOSITORY;

    public User create(User user){
        return REPOSITORY.save(user);
    }

    public User read(String id){
        try {
            return REPOSITORY.findById(id).get();
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid employee username");
        }
    }

    public User update(User user){
        try {
            User updated = new User.Builder().copy(this.read(user.getUserName()))
                    .password(user.getUserPassword())
                    .employee(user.getEmployee())
                    .build();
            return REPOSITORY.save(updated);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid employee username");
        }
    }

    public boolean delete(String id){
        try {
            REPOSITORY.deleteById(id);
            return true;
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid employee username");
        }
    }

    public List<User> getAll(){
        return REPOSITORY.findAll();
    }
}