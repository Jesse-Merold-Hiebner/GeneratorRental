package za.ac.cput.GeneratorRental.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import za.ac.cput.GeneratorRental.domain.Employee;
import za.ac.cput.GeneratorRental.service.EmployeeService;

import java.util.List;

@RestController
@RequestMapping("generatorrental/employee/")
@Slf4j
public class EmployeeController {
    @Autowired
    private EmployeeService SERVICE;

    @PostMapping("create")
    public ResponseEntity<Employee> create(@RequestBody Employee employee){
        return ResponseEntity.ok(SERVICE.create(employee));
    }

    @GetMapping("read/{id}")
    public ResponseEntity<Employee> read(@PathVariable long id){
        return ResponseEntity.ok(SERVICE.read(id));
    }

    @PutMapping("update")
    public ResponseEntity<Employee> update(@RequestBody Employee employee){
        return ResponseEntity.ok(SERVICE.update(employee));
    }

    @DeleteMapping("delete/{id}")
    public ResponseEntity<Boolean> delete(@PathVariable long id){
        return ResponseEntity.ok(SERVICE.delete(id));
    }

    @GetMapping("getAll")
    public ResponseEntity<List<Employee>> getAll(){
        return ResponseEntity.ok(SERVICE.getAll());
    }
}
